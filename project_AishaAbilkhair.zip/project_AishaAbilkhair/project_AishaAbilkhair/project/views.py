from django.shortcuts import render, HttpResponse

# Create your views here.
def index(request):
    return render(request, 'project/index.html')

def about(request):
    return render(request, 'project/about.html')

def resume(request):
    return render(request, 'project/resume.html')
